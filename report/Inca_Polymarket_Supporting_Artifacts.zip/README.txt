Supporting artifacts for the Polymarket informed-trading submission memo.

This package is intentionally smaller than the full working GitHub repository. It includes the reviewed market universe, candidate wallet lead queue, contract movement checks, verification summary, and the scripts needed to reproduce the report-level tables and chart.

Primary document: report/Inca_Polymarket_Submission_Memo.docx
Do not treat personal learning files or earlier experimental wallet tags as part of this support package.
